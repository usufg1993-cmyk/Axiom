package com.axion.assistant.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.axion.assistant.viewmodel.ChatViewModel
import com.axion.assistant.viewmodel.VoiceState
import kotlin.math.PI
import kotlin.math.sin

@Composable
fun VoiceChatScreen(vm: ChatViewModel) {
    val context = LocalContext.current
    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) vm.startVoiceMode() else vm.error = "Mikrofon izni verilmedi."
    }

    fun requestMic() {
        val granted = ContextCompat.checkSelfPermission(
            context, Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (granted) vm.startVoiceMode() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    LaunchedEffect(Unit) { requestMic() }

    val state = vm.voiceState
    Box(modifier = Modifier.fillMaxSize().background(AxionBlack)) {
        Column(
            modifier = Modifier.fillMaxSize().padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Waveform(
                state = state,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(160.dp)
                    .pointerInput(Unit) { detectTapGestures { vm.interruptSpeech() } }
            )
            Spacer(modifier = Modifier.height(32.dp))
            Text(statusText(state, vm.voiceMode), color = AxionWhite, fontSize = 18.sp)
            Text(
                vm.liveText.ifBlank { vm.error.orEmpty() },
                color = AxionGray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 12.dp)
            )
        }

        Row(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = 48.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = { if (vm.voiceMode) vm.pauseVoiceMode() else requestMic() },
                modifier = Modifier.size(64.dp)
            ) {
                Icon(
                    if (vm.voiceMode) Icons.Filled.Mic else Icons.Filled.MicOff,
                    contentDescription = if (vm.voiceMode) "Mikrofonu kapat" else "Mikrofonu aç",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
            IconButton(onClick = { vm.closeVoiceScreen() }, modifier = Modifier.size(64.dp)) {
                Icon(
                    Icons.Filled.Close,
                    contentDescription = "Sesli sohbeti kapat",
                    tint = Color.White,
                    modifier = Modifier.size(32.dp)
                )
            }
        }
    }
}

private fun statusText(state: VoiceState, voiceMode: Boolean): String = when (state) {
    VoiceState.IDLE -> if (voiceMode) "Hazır" else "Mikrofon kapalı"
    VoiceState.LISTENING -> "Sizi dinliyorum..."
    VoiceState.THINKING -> "Düşünüyorum..."
    VoiceState.SPEAKING -> "Konuşuyorum. Kesmek için dokunun."
}

/** Duruma göre değişen ses dalgası: dinlerken gri ve hızlı, konuşurken beyaz ve geniş. */
@Composable
private fun Waveform(state: VoiceState, modifier: Modifier) {
    val target = when (state) {
        VoiceState.IDLE -> 0.06f
        VoiceState.THINKING -> 0.22f
        VoiceState.LISTENING -> 0.7f
        VoiceState.SPEAKING -> 0.95f
    }
    val amplitude by animateFloatAsState(
        targetValue = target,
        animationSpec = tween(durationMillis = 400),
        label = "amplitude"
    )
    val transition = rememberInfiniteTransition(label = "wave")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (2 * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animationSpec = tween(durationMillis = 1200, easing = LinearEasing)
        ),
        label = "phase"
    )
    val speed = if (state == VoiceState.LISTENING) 2.5f else 1f
    val color = if (state == VoiceState.LISTENING) AxionGray else AxionWhite

    Canvas(modifier = modifier) {
        val bars = 21
        val gap = size.width / bars
        val mid = size.height / 2f
        for (i in 0 until bars) {
            val x = gap * (i + 0.5f)
            val wave = (sin(phase * speed + i * 0.45f) + 1f) / 2f
            val h = (0.1f + amplitude * wave * 0.9f) * size.height
            drawLine(
                color = color,
                start = Offset(x, mid - h / 2f),
                end = Offset(x, mid + h / 2f),
                strokeWidth = gap * 0.5f,
                cap = StrokeCap.Round
            )
        }
    }
}
