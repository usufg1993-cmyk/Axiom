package com.axion.assistant.data

import androidx.compose.runtime.snapshots.SnapshotStateList

/** Bir sohbet. Başlık, ilk kullanıcı mesajından türetilir. */
class Conversation(
    val id: String,
    val messages: SnapshotStateList<ChatMessage>
) {
    fun title(): String =
        messages.firstOrNull { it.fromUser }?.text?.replace('\n', ' ')?.take(40)?.ifBlank { null }
            ?: "Yeni sohbet"
}
