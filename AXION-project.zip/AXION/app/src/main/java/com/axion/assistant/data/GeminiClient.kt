package com.axion.assistant.data

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gemini API istemcisi. Model adı değişirse MODEL sabitini güncelleyin.
 * API anahtarı çağıran tarafından verilir; koda gömülmez.
 */
object GeminiClient {
    private const val MODEL = "gemini-2.0-flash"
    private const val SYSTEM_PROMPT =
        "Sen AXION'sun, Türkçe konuşan kişisel bir yapay zekâ asistanısın. " +
        "Cevapların net, kısa ve sesli okunmaya uygun olsun."

    fun ask(apiKey: String, history: List<ChatMessage>): String {
        val contents = JSONArray()
        history.forEach { msg ->
            contents.put(
                JSONObject()
                    .put("role", if (msg.fromUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", msg.text)))
            )
        }

        val body = JSONObject()
            .put(
                "systemInstruction",
                JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM_PROMPT)))
            )
            .put("contents", contents)

        val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 15_000
            readTimeout = 60_000
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }

        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            if (code !in 200..299) throw IllegalStateException("API hatası ($code)")

            val parts = JSONObject(raw)
                .getJSONArray("candidates")
                .getJSONObject(0)
                .getJSONObject("content")
                .getJSONArray("parts")
            return (0 until parts.length()).joinToString("") { parts.getJSONObject(it).optString("text") }
                .ifBlank { "Bir cevap üretilemedi." }
        } finally {
            conn.disconnect()
        }
    }
}
