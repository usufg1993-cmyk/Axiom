package com.axion.assistant.data

data class ChatMessage(
    val text: String,
    val fromUser: Boolean,
    val id: Long = System.nanoTime()
)
