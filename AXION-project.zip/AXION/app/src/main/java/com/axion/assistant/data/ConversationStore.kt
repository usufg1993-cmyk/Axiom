package com.axion.assistant.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Sohbetleri uygulamanın özel depolamasında JSON olarak saklar. */
class ConversationStore(context: Context) {
    private val file = File(context.filesDir, "conversations.json")

    fun load(): List<Conversation> = try {
        val arr = JSONArray(file.readText())
        (0 until arr.length()).map { i ->
            val obj = arr.getJSONObject(i)
            val msgs = obj.getJSONArray("messages")
            val list = mutableStateListOf<ChatMessage>()
            for (j in 0 until msgs.length()) {
                val m = msgs.getJSONObject(j)
                list.add(ChatMessage(m.getString("text"), m.getBoolean("fromUser"), m.getLong("id")))
            }
            Conversation(obj.getString("id"), list)
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(conversations: List<Conversation>) {
        val arr = JSONArray()
        conversations.forEach { conv ->
            val msgs = JSONArray()
            conv.messages.forEach { m ->
                msgs.put(
                    JSONObject()
                        .put("text", m.text)
                        .put("fromUser", m.fromUser)
                        .put("id", m.id)
                )
            }
            arr.put(JSONObject().put("id", conv.id).put("messages", msgs))
        }
        file.writeText(arr.toString())
    }
}
