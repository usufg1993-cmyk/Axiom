package com.axion.assistant.control

import android.content.Context
import android.content.Intent
import java.util.Locale

/** Komutları çalıştırır. Erişilebilirlik gerektiren işlemler, izin yoksa açıkça reddedilir. */
object DeviceController {
    private val locale = Locale("tr", "TR")
    private const val NEEDS_SERVICE =
        "Cihaz kontrolü için Ayarlar > Erişilebilirlik > AXION iznini açmanız gerekiyor."

    fun execute(context: Context, command: DeviceCommand): String = when (command) {
        is DeviceCommand.OpenApp -> openApp(context, command.name)
        is DeviceCommand.OpenSettings -> openSettings(context, command.target)
        DeviceCommand.StopListening -> "Dinlemeyi durdurdum."
        DeviceCommand.Home -> withService { it.goHome(); "Ana ekrana döndüm." }
        DeviceCommand.Back -> withService { it.goBack(); "Geri döndüm." }
        is DeviceCommand.Scroll -> withService { service ->
            val dir = if (command.down) "aşağı" else "yukarı"
            if (service.scroll(command.down)) "Ekranı $dir kaydırdım."
            else "Kaydırabileceğim bir alan bulamadım."
        }
        is DeviceCommand.TypeText -> withService { service ->
            if (service.typeText(command.text)) "Metni yazdım."
            else "Yazabileceğim bir metin alanı bulamadım. Önce bir metin kutusuna dokunun."
        }
    }

    fun openAccessibilitySettings(context: Context) {
        openSettings(context, SettingsTarget.ACCESSIBILITY)
    }

    private fun withService(block: (AxionAccessibilityService) -> String): String {
        val service = AxionAccessibilityService.instance ?: return NEEDS_SERVICE
        return block(service)
    }

    private fun openApp(context: Context, name: String): String {
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0).map { it to it.loadLabel(pm).toString() }
        val match = apps.firstOrNull { it.second.equals(name, ignoreCase = true) }
            ?: apps.firstOrNull { it.second.lowercase(locale).contains(name.lowercase(locale)) }
            ?: return "\"$name\" adlı bir uygulama bulamadım."
        val intent = pm.getLaunchIntentForPackage(match.first.activityInfo.packageName)
            ?: return "${match.second} açılamadı."
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return "${match.second} açılıyor."
    }

    private fun openSettings(context: Context, target: SettingsTarget): String {
        context.startActivity(Intent(target.action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return "${target.label} açılıyor."
    }
}
