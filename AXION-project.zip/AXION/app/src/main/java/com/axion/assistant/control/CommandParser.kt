package com.axion.assistant.control

import android.provider.Settings
import java.util.Locale

sealed class DeviceCommand {
    data object StopListening : DeviceCommand()
    data object Home : DeviceCommand()
    data object Back : DeviceCommand()
    data class Scroll(val down: Boolean) : DeviceCommand()
    data class TypeText(val text: String) : DeviceCommand()
    data class OpenApp(val name: String) : DeviceCommand()
    data class OpenSettings(val target: SettingsTarget) : DeviceCommand()
}

/** Yalnızca izin verilen, sabit ayar ekranlarını açar. Rastgele intent çalıştırmaz. */
enum class SettingsTarget(val action: String, val label: String) {
    GENERAL(Settings.ACTION_SETTINGS, "Ayarlar"),
    ACCESSIBILITY(Settings.ACTION_ACCESSIBILITY_SETTINGS, "Erişilebilirlik ayarları"),
    WIFI(Settings.ACTION_WIFI_SETTINGS, "Wi-Fi ayarları"),
    BLUETOOTH(Settings.ACTION_BLUETOOTH_SETTINGS, "Bluetooth ayarları")
}

/** Türkçe komutları yerel olarak ayrıştırır. Eşleşmezse null döner ve metin Gemini'ye gider. */
object CommandParser {
    private val locale = Locale("tr", "TR")
    private val typeRegex = Regex("^(?:şunu\\s+)?yaz[:\\s]\\s*(.+)$", RegexOption.IGNORE_CASE)
    private val openRegex = Regex(
        "^(.+?)\\s+(?:uygulamas[ıi]n[ıi]|uygulamay[ıi])?\\s*aç$",
        RegexOption.IGNORE_CASE
    )

    fun parse(input: String): DeviceCommand? {
        val text = input.trim()
        val lower = text.lowercase(locale)

        if (lower.contains("dinlemeyi") && (lower.contains("durdur") || lower.contains("bırak"))) {
            return DeviceCommand.StopListening
        }

        typeRegex.find(text)?.let { return DeviceCommand.TypeText(it.groupValues[1].trim()) }

        return when {
            lower.contains("ana ekran") -> DeviceCommand.Home
            lower in setOf("geri", "geri git", "geri dön") -> DeviceCommand.Back
            lower.contains("kaydır") -> DeviceCommand.Scroll(down = !lower.contains("yukarı"))
            lower.contains("erişilebilirlik") && lower.contains("ayar") ->
                DeviceCommand.OpenSettings(SettingsTarget.ACCESSIBILITY)
            (lower.contains("wi-fi") || lower.contains("wifi")) && lower.contains("ayar") ->
                DeviceCommand.OpenSettings(SettingsTarget.WIFI)
            lower.contains("bluetooth") && lower.contains("ayar") ->
                DeviceCommand.OpenSettings(SettingsTarget.BLUETOOTH)
            lower.contains("ayar") && lower.contains("aç") ->
                DeviceCommand.OpenSettings(SettingsTarget.GENERAL)
            else -> openRegex.find(text)?.let { match ->
                val name = match.groupValues[1].substringBefore('\'').trim()
                if (name.isBlank()) null else DeviceCommand.OpenApp(name)
            }
        }
    }
}
