package com.axion.assistant.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AxionBlack = Color(0xFF000000)
val AxionSurface = Color(0xFF111111)
val AxionBubble = Color(0xFF1A1A1A)
val AxionWhite = Color(0xFFFFFFFF)
val AxionGray = Color(0xFFA0A0A0)

private val AxionColors = darkColorScheme(
    background = AxionBlack,
    surface = AxionSurface,
    surfaceVariant = AxionBubble,
    onBackground = AxionWhite,
    onSurface = AxionWhite,
    onSurfaceVariant = AxionGray,
    primary = AxionWhite,
    onPrimary = AxionBlack,
    secondary = AxionGray,
    onSecondary = AxionBlack,
    error = AxionWhite,
    onError = AxionBlack
)

@Composable
fun AxionTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AxionColors, content = content)
}
