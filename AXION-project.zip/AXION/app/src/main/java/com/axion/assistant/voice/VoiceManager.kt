package com.axion.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Türkçe konuşma tanıma (mikrofon) ve sesli cevap (TTS). */
class VoiceManager(context: Context) {
    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var recognizer: SpeechRecognizer? = null
    private var pendingDone: (() -> Unit)? = null

    var onSpeakingChanged: ((Boolean) -> Unit)? = null

    init {
        tts = TextToSpeech(appContext) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (ttsReady) {
                tts?.language = Locale("tr", "TR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = runOnMain { onSpeakingChanged?.invoke(true) }
                    override fun onDone(utteranceId: String?) = finishUtterance()
                    override fun onError(utteranceId: String?) = finishUtterance()
                })
            }
        }
    }

    private fun finishUtterance() = runOnMain {
        onSpeakingChanged?.invoke(false)
        val done = pendingDone
        pendingDone = null
        done?.invoke()
    }

    private fun runOnMain(block: () -> Unit) {
        mainHandler.post { block() }
    }

    fun speak(text: String, onFinished: (() -> Unit)? = null) {
        if (!ttsReady) {
            onFinished?.invoke()
            return
        }
        pendingDone = onFinished
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "axion-${System.nanoTime()}")
    }

    fun stopSpeaking() {
        pendingDone = null
        tts?.stop()
        onSpeakingChanged?.invoke(false)
    }

    fun listen(
        onPartial: (String) -> Unit,
        onResult: (String) -> Unit,
        onError: (String) -> Unit,
        onListeningChanged: (Boolean) -> Unit
    ) {
        if (!SpeechRecognizer.isRecognitionAvailable(appContext)) {
            onError("Konuşma tanıma bu cihazda kullanılamıyor.")
            return
        }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(appContext).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = onListeningChanged(true)
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = onListeningChanged(false)
                override fun onPartialResults(partialResults: Bundle?) {
                    partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull()?.let(onPartial)
                }
                override fun onResults(results: Bundle?) {
                    onListeningChanged(false)
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (text.isNullOrBlank()) onError("Sizi anlayamadım, tekrar deneyin.") else onResult(text)
                }
                override fun onError(error: Int) {
                    onListeningChanged(false)
                    when (error) {
                        SpeechRecognizer.ERROR_CLIENT -> Unit // Bizim iptalimizde gelir, hata değildir.
                        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                            onError("Sizi anlayamadım, tekrar deneyin.")
                        else -> onError("Dinleme hatası (kod $error).")
                    }
                }
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                    .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            )
        }
    }

    fun stopListening() {
        recognizer?.stopListening()
    }

    fun cancelListening() {
        recognizer?.cancel()
    }

    fun release() {
        recognizer?.destroy()
        recognizer = null
        pendingDone = null
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
