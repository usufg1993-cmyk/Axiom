package com.axion.assistant.ui

import android.Manifest
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.axion.assistant.control.DeviceController
import com.axion.assistant.data.ChatMessage
import com.axion.assistant.viewmodel.ChatViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(vm: ChatViewModel = viewModel()) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val listState = rememberLazyListState()
    var input by remember { mutableStateOf("") }
    var showKeyDialog by remember { mutableStateOf(false) }
    val messages = vm.messages

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) vm.startVoice() else vm.error = "Mikrofon izni verilmedi."
    }

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = AxionSurface, drawerContentColor = AxionWhite) {
                Text(
                    "AXION",
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    modifier = Modifier.padding(horizontal = 28.dp, vertical = 24.dp)
                )
                NavigationDrawerItem(
                    label = { Text("Yeni sohbet") },
                    icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                    selected = false,
                    onClick = {
                        vm.newChat()
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Sesli sohbet") },
                    icon = { Icon(Icons.Filled.Mic, contentDescription = null) },
                    selected = false,
                    onClick = {
                        vm.openVoiceScreen()
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                NavigationDrawerItem(
                    label = { Text("Cihaz kontrolü izni") },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    selected = false,
                    onClick = { DeviceController.openAccessibilitySettings(context) },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
                Text(
                    "Sohbet geçmişi",
                    color = AxionGray,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(horizontal = 28.dp, vertical = 12.dp)
                )
                LazyColumn(modifier = Modifier.weight(1f)) {
                    items(vm.conversations, key = { it.id }) { conv ->
                        NavigationDrawerItem(
                            label = { Text(conv.title(), maxLines = 1, overflow = TextOverflow.Ellipsis) },
                            selected = conv.id == vm.currentId,
                            onClick = {
                                vm.openConversation(conv.id)
                                scope.launch { drawerState.close() }
                            },
                            badge = {
                                IconButton(
                                    onClick = { vm.deleteConversation(conv.id) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        Icons.Filled.Delete,
                                        contentDescription = "Sohbeti sil",
                                        tint = AxionGray,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            },
                            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                        )
                    }
                }
                NavigationDrawerItem(
                    label = { Text("Ayarlar") },
                    icon = { Icon(Icons.Filled.Settings, contentDescription = null) },
                    selected = false,
                    onClick = {
                        showKeyDialog = true
                        scope.launch { drawerState.close() }
                    },
                    modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                )
            }
        }
    ) {
        Scaffold(
            containerColor = AxionBlack,
            topBar = {
                TopAppBar(
                    title = { Text("AXION", fontWeight = FontWeight.Bold, color = AxionWhite) },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = AxionBlack),
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "Menü", tint = AxionWhite)
                        }
                    },
                    actions = {
                        IconButton(onClick = { vm.newChat() }) {
                            Icon(Icons.Filled.Add, contentDescription = "Yeni sohbet", tint = AxionWhite)
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (messages.isEmpty()) {
                    Box(
                        modifier = Modifier.weight(1f).fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("AXION", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = AxionWhite)
                            Text(
                                "Merhaba, size nasıl yardımcı olabilirim?",
                                color = AxionGray,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(top = 8.dp)
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier.weight(1f).fillMaxWidth().widthIn(max = 720.dp),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        itemsIndexed(messages, key = { _, m -> m.id }) { index, message ->
                            MessageRow(
                                message = message,
                                isLastAssistant = index == messages.lastIndex && !message.fromUser,
                                onCopy = { copyText(context, it) },
                                onSpeak = { vm.speak(it) },
                                onRegenerate = { vm.regenerate() }
                            )
                        }
                        if (vm.isBusy) {
                            item {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = AxionWhite
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("AXION düşünüyor...", color = AxionGray)
                                }
                            }
                        }
                    }
                }

                vm.error?.let {
                    Text(
                        it,
                        color = AxionGray,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                    )
                }

                InputBar(
                    value = input,
                    onValueChange = { input = it },
                    isListening = vm.isListening,
                    canSend = input.isNotBlank() && !vm.isBusy,
                    onSend = {
                        vm.send(input)
                        input = ""
                    },
                    onMic = {
                        if (vm.isListening) {
                            vm.stopVoice()
                        } else {
                            val granted = ContextCompat.checkSelfPermission(
                                context, Manifest.permission.RECORD_AUDIO
                            ) == PackageManager.PERMISSION_GRANTED
                            if (granted) vm.startVoice()
                            else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                        }
                    }
                )
            }
        }
    }

    if (vm.voiceScreen) {
        VoiceChatScreen(vm)
    }

    if (showKeyDialog) {
        ApiKeyDialog(
            onDismiss = { showKeyDialog = false },
            onSave = {
                vm.saveApiKey(it)
                showKeyDialog = false
            }
        )
    }
}

@Composable
private fun MessageRow(
    message: ChatMessage,
    isLastAssistant: Boolean,
    onCopy: (String) -> Unit,
    onSpeak: (String) -> Unit,
    onRegenerate: () -> Unit
) {
    if (message.fromUser) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Box(
                modifier = Modifier
                    .widthIn(max = 300.dp)
                    .background(AxionBubble, RoundedCornerShape(20.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Text(message.text, color = AxionWhite)
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxWidth().padding(end = 24.dp)) {
            MessageContent(message.text, onCopy = onCopy)
            Row(modifier = Modifier.padding(top = 4.dp)) {
                IconButton(onClick = { onCopy(message.text) }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.ContentCopy, contentDescription = "Kopyala", tint = AxionGray)
                }
                IconButton(onClick = { onSpeak(message.text) }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Filled.VolumeUp, contentDescription = "Sesli dinle", tint = AxionGray)
                }
                if (isLastAssistant) {
                    IconButton(onClick = onRegenerate, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Yeniden oluştur", tint = AxionGray)
                    }
                }
            }
        }
    }
}

/** Metni düz paragraflara ve ``` ile ayrılmış kod bloklarına ayırır. */
@Composable
private fun MessageContent(text: String, onCopy: (String) -> Unit) {
    val parts = text.split("```")
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        parts.forEachIndexed { index, part ->
            if (index % 2 == 0) {
                if (part.isNotBlank()) Text(part.trim(), color = AxionWhite)
            } else {
                CodeBlock(part, onCopy)
            }
        }
    }
}

@Composable
private fun CodeBlock(raw: String, onCopy: (String) -> Unit) {
    val hasLanguageLine = raw.contains('\n')
    val language = if (hasLanguageLine) raw.substringBefore('\n').trim() else ""
    val code = (if (hasLanguageLine) raw.substringAfter('\n') else raw).trimEnd()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(AxionSurface, RoundedCornerShape(12.dp))
            .padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 12.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(
                language.ifBlank { "kod" },
                color = AxionGray,
                fontSize = 12.sp,
                modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { onCopy(code) }, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Filled.ContentCopy, contentDescription = "Kodu kopyala", tint = AxionGray, modifier = Modifier.size(18.dp))
            }
        }
        Text(
            code,
            color = AxionWhite,
            fontFamily = FontFamily.Monospace,
            fontSize = 13.sp,
            modifier = Modifier.horizontalScroll(rememberScrollState())
        )
    }
}

private fun copyText(context: Context, text: String) {
    val clipboard = context.getSystemService(ClipboardManager::class.java)
    clipboard?.setPrimaryClip(ClipData.newPlainText("AXION", text))
}

@Composable
private fun InputBar(
    value: String,
    onValueChange: (String) -> Unit,
    isListening: Boolean,
    canSend: Boolean,
    onSend: () -> Unit,
    onMic: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .widthIn(max = 720.dp)
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .background(AxionBubble, RoundedCornerShape(28.dp))
            .padding(start = 16.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        TextField(
            value = value,
            onValueChange = onValueChange,
            modifier = Modifier.weight(1f),
            placeholder = { Text("AXION'a sor", color = AxionGray) },
            maxLines = 5,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { if (canSend) onSend() }),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = AxionBubble,
                unfocusedContainerColor = AxionBubble,
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent,
                cursorColor = AxionWhite,
                focusedTextColor = AxionWhite,
                unfocusedTextColor = AxionWhite
            )
        )
        IconButton(onClick = onMic) {
            Icon(
                if (isListening) Icons.Filled.Stop else Icons.Filled.Mic,
                contentDescription = "Mikrofon",
                tint = if (isListening) AxionGray else AxionWhite
            )
        }
        IconButton(onClick = onSend, enabled = canSend) {
            Icon(
                Icons.Filled.Send,
                contentDescription = "Gönder",
                tint = if (canSend) AxionWhite else AxionGray
            )
        }
    }
}

@Composable
private fun ApiKeyDialog(onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var key by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = AxionSurface,
        title = { Text("Gemini API anahtarı", color = AxionWhite) },
        text = {
            TextField(
                value = key,
                onValueChange = { key = it },
                placeholder = { Text("AIza...", color = AxionGray) },
                singleLine = true,
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = AxionBubble,
                    unfocusedContainerColor = AxionBubble,
                    focusedTextColor = AxionWhite,
                    unfocusedTextColor = AxionWhite,
                    cursorColor = AxionWhite
                )
            )
        },
        confirmButton = {
            TextButton(onClick = { if (key.isNotBlank()) onSave(key) }) {
                Text("Kaydet", color = AxionWhite)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("İptal", color = AxionGray) }
        }
    )
}
