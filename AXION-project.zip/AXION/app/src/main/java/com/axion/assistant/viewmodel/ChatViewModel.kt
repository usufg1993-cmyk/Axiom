package com.axion.assistant.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.axion.assistant.control.CommandParser
import com.axion.assistant.control.DeviceCommand
import com.axion.assistant.control.DeviceController
import com.axion.assistant.data.ApiKeyStore
import com.axion.assistant.data.ChatMessage
import com.axion.assistant.data.Conversation
import com.axion.assistant.data.ConversationStore
import com.axion.assistant.data.GeminiClient
import com.axion.assistant.voice.VoiceManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

enum class VoiceState { IDLE, LISTENING, THINKING, SPEAKING }

class ChatViewModel(app: Application) : AndroidViewModel(app) {

    private val store = ConversationStore(app)
    private val keyStore = ApiKeyStore(app)
    private val voice = VoiceManager(app)

    val conversations: SnapshotStateList<Conversation> =
        mutableStateListOf<Conversation>().apply { addAll(store.load()) }

    var currentId by mutableStateOf<String?>(null)
        private set
    var isBusy by mutableStateOf(false)
        private set
    var isListening by mutableStateOf(false)
        private set
    var isSpeaking by mutableStateOf(false)
        private set
    var liveText by mutableStateOf("")
        private set
    var voiceScreen by mutableStateOf(false)
        private set
    var voiceMode by mutableStateOf(false)
        private set
    var error by mutableStateOf<String?>(null)

    init {
        voice.onSpeakingChanged = { isSpeaking = it }
    }

    val messages: List<ChatMessage>
        get() = conversations.firstOrNull { it.id == currentId }?.messages ?: emptyList()

    val voiceState: VoiceState
        get() = when {
            isSpeaking -> VoiceState.SPEAKING
            isBusy -> VoiceState.THINKING
            isListening -> VoiceState.LISTENING
            else -> VoiceState.IDLE
        }

    val hasApiKey: Boolean get() = keyStore.apiKey != null

    fun saveApiKey(key: String) {
        keyStore.apiKey = key
        error = null
    }

    fun send(text: String, fromVoice: Boolean = false) {
        val trimmed = text.trim()
        if (trimmed.isEmpty() || isBusy) return
        voice.stopSpeaking()
        val conv = currentOrNew()
        conv.messages.add(ChatMessage(text = trimmed, fromUser = true))
        bringToTop(conv)
        persist()

        val command = CommandParser.parse(trimmed)
        if (command is DeviceCommand.StopListening) pauseVoiceMode()
        if (command != null) {
            val result = DeviceController.execute(getApplication(), command)
            addAssistantMessage(conv, result)
            deliver(result, fromVoice)
        } else {
            requestReply(conv, fromVoice)
        }
    }

    /** Son AI yanıtını siler ve aynı geçmişle yeniden ister. */
    fun regenerate() {
        if (isBusy) return
        val conv = conversations.firstOrNull { it.id == currentId } ?: return
        if (conv.messages.lastOrNull()?.fromUser == false) {
            conv.messages.removeAt(conv.messages.lastIndex)
        }
        if (conv.messages.isEmpty()) return
        persist()
        requestReply(conv, fromVoice = false)
    }

    fun speak(text: String) = voice.speak(text)

    fun openConversation(id: String) {
        currentId = id
        error = null
        voice.stopSpeaking()
    }

    fun newChat() {
        currentId = null
        error = null
        voice.stopSpeaking()
    }

    fun deleteConversation(id: String) {
        conversations.removeAll { it.id == id }
        if (currentId == id) currentId = null
        persist()
    }

    fun openVoiceScreen() {
        error = null
        voiceScreen = true
    }

    fun closeVoiceScreen() {
        voiceMode = false
        voice.cancelListening()
        voice.stopSpeaking()
        isListening = false
        voiceScreen = false
    }

    /** Sesli sohbeti başlatır: dinle → yanıtla → seslendir → tekrar dinle. */
    fun startVoiceMode() {
        voiceMode = true
        startListening()
    }

    fun pauseVoiceMode() {
        voiceMode = false
        voice.cancelListening()
        isListening = false
    }

    /** AXION konuşurken kullanıcı dokunursa sözü keser ve dinlemeye geçer. */
    fun interruptSpeech() {
        voice.stopSpeaking()
        if (voiceMode) startListening()
    }

    /** Sohbet ekranındaki tek seferlik mikrofon. */
    fun startVoice() {
        voiceMode = false
        startListening()
    }

    fun stopVoice() = voice.stopListening()

    private fun startListening() {
        error = null
        liveText = ""
        voice.listen(
            onPartial = { liveText = it },
            onResult = { text ->
                liveText = ""
                send(text, fromVoice = true)
            },
            onError = { message ->
                liveText = ""
                error = message
            },
            onListeningChanged = { isListening = it }
        )
    }

    private fun deliver(text: String, fromVoice: Boolean) {
        if (!fromVoice) return
        voice.speak(text) {
            if (voiceMode) startListening()
        }
    }

    private fun addAssistantMessage(conv: Conversation, text: String) {
        conv.messages.add(ChatMessage(text = text, fromUser = false))
        persist()
    }

    private fun currentOrNew(): Conversation {
        conversations.firstOrNull { it.id == currentId }?.let { return it }
        val conv = Conversation(UUID.randomUUID().toString(), mutableStateListOf())
        conversations.add(0, conv)
        currentId = conv.id
        return conv
    }

    private fun bringToTop(conv: Conversation) {
        if (conversations.indexOf(conv) > 0) {
            conversations.remove(conv)
            conversations.add(0, conv)
        }
    }

    private fun requestReply(conv: Conversation, fromVoice: Boolean) {
        val key = keyStore.apiKey
        if (key == null) {
            error = "Önce ayarlardan API anahtarınızı girin."
            return
        }
        isBusy = true
        error = null
        viewModelScope.launch {
            try {
                val history = conv.messages.toList().takeLast(MAX_HISTORY)
                val reply = withContext(Dispatchers.IO) { GeminiClient.ask(key, history) }
                addAssistantMessage(conv, reply)
                deliver(reply, fromVoice)
            } catch (e: Exception) {
                error = e.message ?: "Bağlantı hatası. İnternetinizi kontrol edin."
            } finally {
                isBusy = false
            }
        }
    }

    private fun persist() = store.save(conversations.toList())

    override fun onCleared() {
        voice.release()
        super.onCleared()
    }

    private companion object {
        const val MAX_HISTORY = 30
    }
}
