package com.axion.assistant.voice

/**
 * Uyandırma kelimesi altyapısı.
 * Gerçek bir motor (ör. Porcupine veya Vosk) eklenene kadar bu uygulama hiçbir arka plan
 * dinlemesi yapmaz. isAvailable false iken arayüz bunu "etkin değil" olarak göstermelidir.
 */
interface WakeWordDetector {
    val isAvailable: Boolean
    fun start(onWake: () -> Unit)
    fun stop()
}

class UnavailableWakeWordDetector : WakeWordDetector {
    override val isAvailable: Boolean = false
    override fun start(onWake: () -> Unit) = Unit
    override fun stop() = Unit
}
